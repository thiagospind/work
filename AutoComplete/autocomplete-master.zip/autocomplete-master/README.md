Autocomplete with PHP, MySQL and Jquery UI
=============

These files acompany the tutorial: [Autocomplete with PHP, MySQL and Jquery UI](http://daveismyname.com/autocomplete-with-php-mysql-and-jquery-ui-bp)