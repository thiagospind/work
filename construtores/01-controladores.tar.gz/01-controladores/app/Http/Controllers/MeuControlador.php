<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class MeuControlador extends Controller
{
    public function getNome() {
        return "Jose da Silva";
    }
    
    public function getIdade() {
        return "20 anos";
    }
    
    public function multiplicar($a, $b) {
        return $a * $b;
    }
    
    public function getNomePorId($id) {
        $v = [ "Mario", "Edson", "Roberto", "Joao" ];
        if ($id < count($v) && $id >= 0)
            return $v[ $id ];
        return "Nao encontrado";
    }
}
